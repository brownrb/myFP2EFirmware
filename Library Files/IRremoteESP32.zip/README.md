# IRremoteESP32
This library is a modified library from Ken Shirriff SDD1306ASCIIWire library.
http://arcfn.com/2009/08/multi-protocol-infrared-remote-library.html

It has been tested with 
- ESP32

The modifications were done by
Robert Brown
as part of the myFocuserPro2 focuser project.
